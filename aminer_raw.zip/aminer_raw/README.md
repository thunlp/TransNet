# Data Format

This dataset is extracted from [AMiner](https://aminer.org/aminernetwork).

* author.txt

 Each line contains a numeric author identifier and his name.

    1   O. Willum

 * tag.txt

 Each line contains a numeric label identifier and its name.

    0   neural_network

 * aminer.txt

This file contain a list of all of the author-to-author links and the labels on the links. All links are treated as undirected. Each line contains two author identifiers and its label identifiers.

    522324 1034146 261 2 1217 386 4609 351 2180
    author1 author2 t1 t2 ... tn